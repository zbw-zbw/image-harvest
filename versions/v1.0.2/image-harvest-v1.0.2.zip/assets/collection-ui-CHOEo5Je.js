import{n as h,h as i,b as w,_ as g,o as b,u as m,a as x,q as L,r as k,i as E,e as a,t as d,v as $,w as B,x as C,y as S,z as _,s as A}from"./init-DlnzWR9X.js";import"./utils-n2Kn-_Dg.js";import"./license-BEJbWYfK.js";function P(){A.collectionModalState={open:!0};const e=document.getElementById("collection-modal")?.querySelector(".modal-body");e&&(e.scrollTop=0);const t=document.getElementById("collection-search");t&&(t.value="",t.oninput=()=>{u(t.value.trim())}),u()}async function u(c=""){if(a.collectionBody)try{let e=await h();if(c){const t=c.toLowerCase();e=e.filter(o=>o.url&&o.url.toLowerCase().includes(t)||o.sourceTitle&&o.sourceTitle.toLowerCase().includes(t)||o.sourceUrl&&o.sourceUrl.toLowerCase().includes(t)||o.tags&&o.tags.some(l=>l.toLowerCase().includes(t)))}if(e.sort((t,o)=>(o.createdAt||0)-(t.createdAt||0)),e.length===0){a.collectionBody.innerHTML=`
        <div class="collection-empty">
          <div class="collection-empty-icon"><svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg></div>
          <p>${c?d("collection_no_match"):d("collection_empty_title")}</p>
          <p style="font-size:11px;margin-top:4px;color:var(--text-tertiary)">${c?d("collection_no_match_hint"):d("collection_empty_hint")}</p>
        </div>`;return}a.collectionBody.innerHTML=`
      <div class="collection-grid">
        ${e.map(t=>{const o=t.width&&t.height?`${t.width}×${t.height}`:"",l=(t.format||"unknown").toUpperCase(),r=t.fileSize?$(t.fileSize):"";return`
          <div class="image-card collection-card" data-id="${t.id}">
            <div class="card-thumb checkerboard">
              <img src="${t.url}" alt="" loading="lazy">
            </div>
            <div class="card-info-bar">
              <div class="card-tags">
                <span class="card-tag format">${l}</span>
                ${o?`<span class="card-tag dims">${o}</span>`:""}
                ${r?`<span class="card-tag filesize">${r}</span>`:""}
              </div>
              <div class="card-actions">
                <button class="card-action-btn btn-search-collection" title="Reverse search" data-url="${t.url}">
                  <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
                </button>
                <button class="card-action-btn btn-dl-collection" data-url="${t.url}" data-format="${t.format||""}" title="Download">
                  <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
                </button>
                <button class="card-action-btn btn-remove-collection" data-id="${t.id}" title="Remove from collection">
                  <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>
                </button>
              </div>
            </div>
            <div class="card-url-row">
              <div class="card-url" title="${t.url}">${t.url}</div>
              <div class="card-url-actions">
                <button class="card-action-btn btn-copy-collection" data-url="${t.url}" title="Copy URL">
                  <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>
                </button>
                <button class="card-action-btn btn-open-collection" data-url="${t.url}" title="Open in new tab">
                  <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/><polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/></svg>
                </button>
              </div>
            </div>
          </div>`}).join("")}
      </div>`,a.collectionBody.querySelectorAll(".btn-remove-collection").forEach(t=>{t.addEventListener("click",async o=>{o.stopPropagation(),await B(t.dataset.id);const l=document.querySelector(`.image-card[data-id="${t.dataset.id}"] .btn-favorite`);l&&(l.classList.remove("favorited"),l.title="Add to collection"),u(a.collectionSearch?.value?.trim()||"")})}),a.collectionBody.querySelectorAll(".btn-open-collection").forEach(t=>{t.addEventListener("click",o=>{o.stopPropagation(),C(t.dataset.url)})}),a.collectionBody.querySelectorAll(".btn-copy-collection").forEach(t=>{t.addEventListener("click",async o=>{o.stopPropagation();try{await navigator.clipboard.writeText(t.dataset.url),i("URL copied","success")}catch{i("Failed to copy URL","error")}})}),a.collectionBody.querySelectorAll(".btn-dl-collection").forEach(t=>{t.addEventListener("click",o=>{o.stopPropagation();const l={url:t.dataset.url,format:t.dataset.format||"unknown"};S(l,null)})}),a.collectionBody.querySelectorAll(".btn-search-collection").forEach(t=>{t.addEventListener("click",o=>{o.stopPropagation(),_(t.dataset.url,o.currentTarget)})}),a.collectionBody.querySelectorAll(".card-thumb img").forEach(t=>{t.addEventListener("load",()=>{t.classList.add("loaded"),t.parentElement?.classList.add("loaded")}),t.addEventListener("error",()=>{t.style.display="none",t.parentElement?.classList.add("loaded")})})}catch{a.collectionBody.innerHTML=`
      <div class="collection-empty">
        <div class="collection-empty-icon"><svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg></div>
        <p>Failed to load collection</p>
      </div>`}}async function R(){let c=!1;try{const e=await h();if(e.length===0){i("Collection is empty","info");return}w("Exporting collection...",()=>{c=!0,i("Export cancelled","info")});const{default:t}=await g(async()=>{const{default:n}=await import("./jszip.min-BiHF8TMC.js").then(s=>s.j);return{default:n}},[]),o=new t,l=await b(),r=o.folder("collection");for(let n=0;n<e.length;n++){if(c)return;m(n+1,e.length,x(e[n].url,40));try{const s=await fetch(e[n].url,{mode:"cors"});if(s.ok){const f=await s.blob();r.file(L(e[n],n,null,l),f)}}catch{}}if(c)return;const v=await o.generateAsync({type:"blob"}),p=URL.createObjectURL(v),y=k(new Date);await chrome.downloads.download({url:p,filename:`collection-${y}.zip`,saveAs:!1}),URL.revokeObjectURL(p),i("Collection exported","success")}catch{c||i("Export failed","error")}finally{E()}}export{R as exportCollection,u as loadCollection,P as showCollectionModal};
//# sourceMappingURL=collection-ui-CHOEo5Je.js.map
