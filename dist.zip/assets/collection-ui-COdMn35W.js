import{g as v,x as i,z as e,v as g,_ as w,o as _,C as m,A as b,m as x,l as $,p as L,j as c,k,s as B,q as E,i as C,w as S,y as A}from"./init-DP2hEAcI.js";import"./constants-BVE4QN8a.js";import"./telemetry-DcJDd7uD.js";import"./ai-free-quota-FQr-ETq3.js";import"./utils-CLxroVtG.js";function U(){A.collectionModalState={open:!0};const l=document.getElementById("collection-modal")?.querySelector(".modal-body");l&&(l.scrollTop=0);const t=document.getElementById("collection-search");t&&(t.value="",t.oninput=()=>{u(t.value.trim())}),u()}async function u(n=""){if(c.collectionBody)try{let l=await v();if(n){const t=n.toLowerCase();l=l.filter(o=>o.url&&o.url.toLowerCase().includes(t)||o.sourceTitle&&o.sourceTitle.toLowerCase().includes(t)||o.sourceUrl&&o.sourceUrl.toLowerCase().includes(t)||o.tags&&o.tags.some(a=>a.toLowerCase().includes(t)))}if(l.sort((t,o)=>(o.createdAt||0)-(t.createdAt||0)),l.length===0){c.collectionBody.innerHTML=`
        <div class="collection-empty">
          <div class="collection-empty-icon"><svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg></div>
          <p>${n?e("collection_no_match"):e("collection_empty_title")}</p>
          <p style="font-size:11px;margin-top:4px;color:var(--text-tertiary)">${n?e("collection_no_match_hint"):e("collection_empty_hint")}</p>
        </div>`;return}c.collectionBody.innerHTML=`
      <div class="collection-grid">
        ${l.map(t=>{const o=t.width&&t.height?`${t.width}×${t.height}`:"",a=(t.format||"unknown").toUpperCase(),s=t.fileSize?k(t.fileSize):"";return`
          <div class="image-card collection-card" data-id="${t.id}">
            <div class="card-thumb checkerboard">
              <img src="${t.url}" alt="" loading="lazy">
            </div>
            <div class="card-info-bar">
              <div class="card-tags">
                <span class="card-tag format">${a}</span>
                ${o?`<span class="card-tag dims">${o}</span>`:""}
                ${s?`<span class="card-tag filesize">${s}</span>`:""}
              </div>
              <div class="card-actions">
                <button class="card-action-btn btn-search-collection" title="${e("menu_reverse_search")}" data-url="${t.url}">
                  <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
                </button>
                <button class="card-action-btn btn-dl-collection" data-url="${t.url}" data-format="${t.format||""}" title="Download">
                  <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
                </button>
                <button class="card-action-btn btn-remove-collection" data-id="${t.id}" title="${e("card_remove_from_collection")}">
                  <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>
                </button>
              </div>
            </div>
            <div class="card-url-row">
              <div class="card-url" title="${t.url}">${t.url}</div>
              <div class="card-url-actions">
                <button class="card-action-btn btn-copy-collection" data-url="${t.url}" title="${e("card_copy_url")}">
                  <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>
                </button>
                <button class="card-action-btn btn-open-collection" data-url="${t.url}" title="${e("card_open_in_new_tab")}">
                  <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/><polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/></svg>
                </button>
              </div>
            </div>
          </div>`}).join("")}
      </div>`,c.collectionBody.querySelectorAll(".btn-remove-collection").forEach(t=>{t.addEventListener("click",async o=>{o.stopPropagation(),await B(t.dataset.id);const a=document.querySelector(`.image-card[data-id="${t.dataset.id}"] .btn-favorite`);a&&(a.classList.remove("favorited"),a.title="Add to collection"),u(c.collectionSearch?.value?.trim()||"")})}),c.collectionBody.querySelectorAll(".btn-open-collection").forEach(t=>{t.addEventListener("click",o=>{o.stopPropagation(),E(t.dataset.url)})}),c.collectionBody.querySelectorAll(".btn-copy-collection").forEach(t=>{t.addEventListener("click",async o=>{o.stopPropagation();try{await navigator.clipboard.writeText(t.dataset.url),i(e("toast_url_copied_single"),"success")}catch{i(e("toast_url_copy_failed"),"error")}})}),c.collectionBody.querySelectorAll(".btn-dl-collection").forEach(t=>{t.addEventListener("click",o=>{o.stopPropagation();const a={url:t.dataset.url,format:t.dataset.format||"unknown"};C(a,null)})}),c.collectionBody.querySelectorAll(".btn-search-collection").forEach(t=>{t.addEventListener("click",o=>{o.stopPropagation(),S(t.dataset.url,o.currentTarget)})}),c.collectionBody.querySelectorAll(".card-thumb img").forEach(t=>{t.addEventListener("load",()=>{t.classList.add("loaded"),t.parentElement?.classList.add("loaded")}),t.addEventListener("error",()=>{t.style.display="none",t.parentElement?.classList.add("loaded")})})}catch{c.collectionBody.innerHTML=`
      <div class="collection-empty">
        <div class="collection-empty-icon"><svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg></div>
        <p>${e("toast_collection_load_failed")}</p>
      </div>`}}async function H(){let n=!1;try{const l=await v();if(l.length===0){i(e("toast_collection_empty"),"info");return}g(e("toast_exporting_collection"),()=>{n=!0,i(e("toast_export_cancelled"),"info")});const{default:t}=await w(async()=>{const{default:r}=await import("./jszip.min-BiHF8TMC.js").then(d=>d.j);return{default:r}},[]),o=new t,a=await _(),s=o.folder("collection");for(let r=0;r<l.length;r++){if(n)return;m(r+1,l.length,b(l[r].url,40));try{const d=await fetch(l[r].url,{mode:"cors"});if(d.ok){const f=await d.blob();s.file(x(l[r],r,null,a),f)}}catch{}}if(n)return;const h=await o.generateAsync({type:"blob"}),p=URL.createObjectURL(h),y=$(new Date);await chrome.downloads.download({url:p,filename:`collection-${y}.zip`,saveAs:!1}),URL.revokeObjectURL(p),i(e("toast_collection_exported"),"success")}catch{n||i(e("toast_collection_export_failed"),"error")}finally{L()}}export{H as exportCollection,u as loadCollection,U as showCollectionModal};
//# sourceMappingURL=collection-ui-COdMn35W.js.map
