import{y as i,z as o,d as u,x as c,u as g,t as f,a as _,h}from"./init-DP2hEAcI.js";import"./constants-BVE4QN8a.js";import"./telemetry-DcJDd7uD.js";import"./ai-free-quota-FQr-ETq3.js";import"./utils-CLxroVtG.js";function S(){i.dedupModalState={open:!0},requestAnimationFrame(()=>{requestAnimationFrame(()=>{v()})})}function p(){const e=new Set(i.filteredImages.map(t=>t.id));return i.similarGroups.map(t=>t.filter(s=>e.has(s.id))).filter(t=>t.length>=2)}function v(){const t=document.getElementById("dedup-modal")?.querySelector(".modal-body");t&&(t.scrollTop=0);const s=document.getElementById("dedup-body");if(!s)return;const d=p();if(d.length===0){s.innerHTML=`<p class="empty-message">${o("dedup_no_similar")}</p>`;return}s.innerHTML=`${d.map((a,n)=>`
      <div class="dedup-group" data-group="${n}">
        <div class="dedup-group-title">${o("dedup_group_title",{index:n+1,count:a.length})}</div>
        <div class="dedup-group-images">
          ${a.map((l,r)=>`
            <div class="dedup-image" data-group="${n}" data-index="${r}" data-img-id="${l.id}">
              <div class="dedup-image-thumb">
                <img src="${l.url}" alt="">
              </div>
            </div>
          `).join("")}
        </div>
      </div>
    `).join("")}`,s.querySelectorAll(".dedup-image").forEach(a=>{a.addEventListener("click",()=>{a.classList.toggle("selected")})})}async function x(){if(!i.isProUser){u(),c(o("pro_feature_blocked_dedup"),"warning"),g();return}const e=new Set,t=p();if(t.forEach((d,a)=>{d.forEach((n,l)=>{const r=document.querySelector(`.dedup-image[data-group="${a}"][data-index="${l}"]`);if(r&&r.classList.contains("selected")){const m=r.dataset.imgId;m&&e.add(m)}})}),e.size===0&&t.forEach(d=>{for(let a=1;a<d.length;a++)e.add(d[a].id)}),e.size===0){c(o("toast_no_duplicates_found"),"info");return}await f({title:o("confirm_remove_duplicates_title"),message:o("confirm_remove_duplicates_message",{count:e.size}),confirmText:o("common_remove"),cancelText:o("common_cancel"),type:"danger"})&&(i.allImages=i.allImages.filter(d=>!e.has(d.id)),i.selectedImages=new Set([...i.selectedImages].filter(d=>!e.has(d))),u(),_(),h(),c(o("toast_duplicates_removed",{count:e.size}),"success"))}export{x as removeDuplicates,S as showDedupModal};
//# sourceMappingURL=dedup-ui-Duo_3hzN.js.map
