import{f as s,n,s as r,o as u,b as m,k as p,q as g,t as c}from"./init-RdttElN1.js";import"./utils-dhR0vVcK.js";import"./license-BvXHrPD3.js";function h(){s.dedupModalState={open:!0};const t=document.getElementById("dedup-modal")?.querySelector(".modal-body");t&&(t.scrollTop=0);const e=document.getElementById("dedup-body");if(e){if(s.similarGroups.length===0){e.innerHTML=`<p class="empty-message">${c("dedup_no_similar")}</p>`;return}e.innerHTML=`${s.similarGroups.map((a,i)=>`
      <div class="dedup-group" data-group="${i}">
        <div class="dedup-group-title">${c("dedup_group_title",{index:i+1,count:a.length})}</div>
        <div class="dedup-group-images">
          ${a.map((l,o)=>`
            <div class="dedup-image" data-group="${i}" data-index="${o}">
              <div class="dedup-image-thumb">
                <img src="${l.url}" alt="">
              </div>
            </div>
          `).join("")}
        </div>
      </div>
    `).join("")}`,e.querySelectorAll(".dedup-image").forEach(a=>{a.addEventListener("click",()=>{a.classList.toggle("selected")})})}}async function $(){if(!s.isProUser){n(),r("Removing duplicates is a Pro feature. Upgrade to unlock!","warning"),u();return}const d=new Set;if(s.similarGroups.forEach((e,a)=>{e.forEach((i,l)=>{const o=document.querySelector(`.dedup-image[data-group="${a}"][data-index="${l}"]`);o&&o.classList.contains("selected")&&d.add(i.id)})}),d.size===0&&s.similarGroups.forEach(e=>{for(let a=1;a<e.length;a++)d.add(e[a].id)}),d.size===0){r("No duplicate images found","info");return}await m({title:"Remove Duplicates",message:`Are you sure you want to remove ${d.size} selected duplicate image${d.size>1?"s":""}?`,confirmText:"Remove",cancelText:"Cancel",type:"danger"})&&(s.allImages=s.allImages.filter(e=>!d.has(e.id)),s.selectedImages=new Set([...s.selectedImages].filter(e=>!d.has(e))),n(),p(),g(),r(`Removed ${d.size} duplicate images`,"success"))}export{$ as removeDuplicates,h as showDedupModal};
//# sourceMappingURL=dedup-ui-C15vl893.js.map
